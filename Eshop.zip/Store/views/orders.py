from django.shortcuts import render,redirect
from Store.models.product import Product
from Store.models.customer import Customer
from django.views import View
from Store.models.orders import Order
from django.contrib.auth.hashers import make_password,check_password



class Orders(View):

    def get(self,request):
        customer=request.session.get('customer')
        order=Order.get_order_by_customer_id(customer)
        # print(order)
        order=order.reverse()
        return render(request,'orders.html',{'orders':order})
