from django.shortcuts import render,redirect
from Store.models.product import Product
from Store.models.customer import Customer
from django.views import View
from Store.models.orders import Order
from django.contrib.auth.hashers import make_password,check_password


class CheckOut(View):
    def post(self,request):
        address=request.POST.get('address')
        phone=request.POST.get('phone')
        customer=request.session.get('customer')
        cart=request.session.get('cart')
        products=Product.get_Product_by_id(list(cart.keys()))

        # print(address,phone,customer,cart,product)

        for product in products:
            # print(cart.get(str(product.id)))
            order=Order(customer=Customer(id=customer),
                        product=product,
                        price=product.price,
                        address=address,
                        phone=phone,
                        quantity=cart.get(str(product.id)))
            order.placeOrder();

        request.session['cart']={}
        return redirect('cart')
