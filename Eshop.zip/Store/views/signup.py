from django.shortcuts import render,redirect
from django.http import HttpResponse
from Store.models.customer import Customer
from django.views import View
from django.contrib.auth.hashers import make_password,check_password

class Signup(View):
    def get(self,request):
        return render(request,'signup.html')

    def post(self,request):
            postData=request.POST
            first_name=postData.get('firstname')
            last_name=postData.get('lastname')
            email=postData.get('email')
            password=postData.get('password')
            confirm_password=postData.get('confirm_password')
            phone=postData.get('phone')
            customer=Customer(first_name=first_name,
                              last_name=last_name,
                              email=email,
                              password=password,
                              phone=phone)
            #validation
            value={
            'first_name':first_name,
            'last_name':last_name,
            'email':email,
            'phone':phone
            }


            error_message= self.validateCustomer(customer,confirm_password)

            #saveing
            if not error_message:

            #    print(first_name,last_name,email,password,phone)
                customer.password=make_password(customer.password)

                customer.register()
                return redirect('homepage')

            else:
                data={
                'error':error_message,
                'value':value
                }
                return render(request,'signup.html',data)
    def validateCustomer(self,customer,confirm_password):
        error_message=None
        if not customer.first_name:
            error_message="first Name Requir !!"
        elif len(customer.first_name)<4:
            error_message="first name must be 4 letter long or more"
        elif not customer.email:
            error_message="email requir"
        elif len(customer.phone)<10 and len(customer.phone)>10:
            error_message="phone number must be 10"
        elif customer.password!=None and customer.password!=confirm_password:
            error_message="password must be same"
        elif customer.isExist():
            error_message="Email Address Already Registered"

        return error_message
