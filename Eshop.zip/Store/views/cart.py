from django.shortcuts import render,redirect
from Store.models.product import Product
from Store.models.customer import Customer
from django.views import View
from django.contrib.auth.hashers import make_password,check_password


class Cart(View):
    def get(self,request):
        ids=list(request.session.get('cart').keys())
        products=Product.get_Product_by_id(ids)
        # print(ids)
        return render(request,'cart.html',{'products':products})
